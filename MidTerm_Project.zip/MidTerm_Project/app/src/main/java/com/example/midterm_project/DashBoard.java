package com.example.midterm_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class DashBoard extends AppCompatActivity {
    private Button add_btn;

    public boolean compare_hours ( int default_hours, int actual ){
        if ( default_hours > actual ) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);

        TextView welcome_msg = (TextView) findViewById(R.id.welcome_text);
        String student_name = getIntent().getStringExtra("student_name");

        welcome_msg.setText("Welcome " + student_name);

        final RadioButton graduated, ungraduated;
        graduated = (RadioButton) findViewById(R.id.rb1);
        ungraduated = (RadioButton) findViewById(R.id.rb2);

        final int course_fees[] = {1300, 1500, 1350, 1400, 1000};
        final int hours_per_weeks[] = {6, 5, 5, 7, 4};
        final int[] max_hour = {0};

        final Spinner course_choice = (Spinner) findViewById(R.id.courses);
        final ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(
             DashBoard.this,
            android.R.layout.simple_list_item_1,
            getResources().getStringArray(R.array.courses)
        );

        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        course_choice.setAdapter(myAdapter);

        final int[] total_course_fee = {0};
        final int[] total_hours = {0};

        course_choice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int get_fee = course_fees[position];
                int get_time = hours_per_weeks[position];

                total_course_fee[0] = get_fee;
                total_hours[0] = get_time;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        final TextView display_fee, display_time;
        display_fee = (TextView) findViewById(R.id.course_fee);
        display_time = (TextView) findViewById(R.id.course_time);

        add_btn = (Button) findViewById(R.id.add_btn);

        final int[] stack_total_free = {0};
        final int[] stack_total_hours = {0};

        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stack_total_free[0] += total_course_fee[0];
                stack_total_hours[0] += total_hours[0];

                if ( graduated.isChecked() ) {
                    max_hour[0] = 21;
                }

                if ( ungraduated.isChecked() ) {
                    max_hour[0] = 19;
                }

                if (compare_hours( max_hour[0], stack_total_hours[0] )) {
                    display_fee.setText(String.valueOf(stack_total_free[0]));
                    display_time.setText(String.valueOf(stack_total_hours[0]));

                } else {
                    int duration = Toast.LENGTH_LONG;
                    String alert_message = "You cannot add this course.";
                    Toast toast = Toast.makeText(DashBoard.this, alert_message, duration);
                    toast.show();
                }
            }
        });
    }
}