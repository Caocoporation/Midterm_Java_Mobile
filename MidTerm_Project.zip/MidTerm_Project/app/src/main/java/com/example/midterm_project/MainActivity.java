package com.example.midterm_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button login_button;

    public void moveToDashBoard(String set_username){
        Intent intent = new Intent(this, DashBoard.class);
        intent.putExtra("student_name", set_username);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView alert_message;
        final EditText username, password;
//        Button login_button;

        username = (EditText) findViewById(R.id.get_username);
        password = (EditText) findViewById(R.id.get_password);
        login_button = (Button) findViewById(R.id.login_btn);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int duration = Toast.LENGTH_LONG;
                String alert_message = "";
                String get_username = username.getText().toString();
                String get_password = password.getText().toString();

                String dummy_username = "student1";
                String dummy_password = "123456";

                if (get_username.length() == 0 ) {
                    alert_message = "Please enter your username";

                }

                if (get_password.length() == 0 ) {
                    alert_message = "Please enter your password";
                }

                if ( get_password.equals(dummy_password) && get_username.equals(dummy_username)) {
                    moveToDashBoard(get_username);
                }
                else{
                    alert_message = "Invalid username or password.";
                }

                Toast toast = Toast.makeText(MainActivity.this, alert_message, duration);
                toast.show();
            }
        });

    }
}